
murders_by_race <-
murders %>%
  group_by (victim_race, offender_race) %>%
  summarize ( num_of_cases = n() ) %>%
  arrange (victim_race, desc(num_of_cases)
           ) 

murders %>% 
 group_by (victim_race) %>%
 summarize (subtotal = n() ) %>%
 mutate (pct_total = subtotal / sum(subtotal, na.rm=TRUE) * 100)

spread(murders_by_race, key=victim_race, value=num_of_cases) %>%
  datatable()


murder_ages <-
  murders_with_counties %>%
  mutate (victim_age = case_when (victim_age == 999 ~ NA_real_, 
                                TRUE ~ victim_age), 
        offender_age = case_when (offender_age == 999 ~ NA_real_, 
                                  TRUE ~ offender_age)
        )
